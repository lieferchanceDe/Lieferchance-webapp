# LieferChance WebApp

Dies ist eine moderne Webanwendung für öffentliche Ausschreibungen.